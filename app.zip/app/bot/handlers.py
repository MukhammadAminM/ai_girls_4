import logging
import math
from pathlib import Path

from aiogram import Router
from aiogram.filters import Command, CommandStart
from aiogram.types import (
    BufferedInputFile,
    CallbackQuery,
    FSInputFile,
    InlineKeyboardButton,
    InlineKeyboardMarkup,
    KeyboardButton,
    Message,
    ReplyKeyboardMarkup,
    ReplyKeyboardRemove,
)

from app.db import get_session
from app.repositories.girls import ensure_default_girl, get_all_girls, get_default_girl, get_girl_by_id
from app.repositories.dialogs import (
    create_dialog,
    get_active_dialog,
    get_all_user_dialogs,
    get_dialog_by_id,
    get_user_dialogs_with_girl,
)
from app.repositories.messages import (
    add_message,
    clear_dialog,
    get_all_messages,
    get_girls_with_history,
    get_message_count,
    get_recent_messages,
)
from app.repositories.user_selected_girl import (
    get_active_dialog_id,
    get_selected_girl,
    set_active_dialog,
    set_selected_girl,
)
from app.services.image_client import ImageClient
from app.services.venice_client import VeniceClient
from app.bot.task_helpers import (
    enqueue_image_generation,
    enqueue_reply_generation,
    send_image_from_task_result,
    wait_for_task_result,
)

router = Router()

GIRLS_PER_PAGE = 2
DIALOGS_PER_PAGE = 5
MAX_PHOTOS_PER_DIALOG = 9999

# Словарь для отслеживания состояния генерации изображений по user_id
# Хранит ссылку на сообщение-предупреждение, которое нужно удалить после генерации
_generating_images: dict[int, Message | None] = {}

# Путь к папке с изображениями девушек
GIRLS_IMAGES_DIR = Path("girls_images")


def get_girl_image_path(girl_name: str) -> Path | None:
    """Возвращает путь к изображению девушки или None, если файл не найден."""
    # Маппинг имен девушек к именам файлов
    name_mapping = {
        "Стейси": "staicy.png",
        "Аманда": "amanda.png",
        "Джейн": "jane.png",
    }
    
    filename = name_mapping.get(girl_name)
    if not filename:
        return None
    
    image_path = GIRLS_IMAGES_DIR / filename
    if image_path.exists():
        return image_path
    return None


def get_girl_description(girl) -> str:
    """Формирует описание девушки на основе её данных."""
    # Информация о девушках
    descriptions = {
        "Стейси": "👩‍🎓 19 лет\n📚 Одногруппница\n💬 Дружелюбная, умная, игривая",
        "Аманда": "👩 32 года\n🏠 Соседка\n💔 Разведёнка\n💋 Опытная милфа",
        "Джейн": "👩‍🌾 22 года\n🌾 Из деревни\n🧡 Рыжеволосая\n🏡 Хозяйственная",
    }
    
    return descriptions.get(girl.name, f"💬 {girl.name}")


def get_girl_story_intro(girl_name: str) -> str:
    """Возвращает введение в сюжет для персонажа."""
    story_intros = {
        "Стейси": (
            "Ты решил зайти к Стейси, чтобы вместе разобраться с домашним заданием. "
            "Она пригласила тебя к себе домой, и теперь вы сидите за столом с тетрадками и учебниками. "
            "Стейси дружелюбно улыбается и готова помочь с любыми вопросами."
        ),
        "Аманда": (
            "Ты решил познакомиться со своей соседкой Амандой. "
            "Она живет напротив и часто видит тебя в подъезде. "
            "Сегодня она попросила помочь с чем-то или просто пригласила зайти поболтать. "
            "Ты стоишь у её двери, готовый постучать."
        ),
        "Джейн": (
            "Ты приехал в деревню и решил познакомиться с местными жителями. "
            "Джейн — хозяйственная девушка, которая живет неподалеку. "
            "Ты видишь её во дворе, где она занимается хозяйством. "
            "Она заметила тебя и дружелюбно помахала рукой."
        ),
    }
    
    return story_intros.get(girl_name, "Ты решил начать диалог с этим персонажем.")


def get_main_keyboard() -> ReplyKeyboardMarkup:
    """Возвращает основную клавиатуру (главное меню, история чатов)."""
    keyboard = ReplyKeyboardMarkup(
        keyboard=[
            [KeyboardButton(text="🏠 Главное меню"), KeyboardButton(text="📜 История чатов")],
        ],
        resize_keyboard=True,
    )
    return keyboard


def get_dialogue_keyboard() -> ReplyKeyboardMarkup:
    """Возвращает клавиатуру для диалога (все основные + завершить/начать заново)."""
    keyboard = ReplyKeyboardMarkup(
        keyboard=[
            [KeyboardButton(text="🏠 Главное меню"), KeyboardButton(text="📜 История чатов")],
            [KeyboardButton(text="❌ Завершить диалог"), KeyboardButton(text="🔄 Начать диалог заново")],
        ],
        resize_keyboard=True,
    )
    return keyboard


def build_image_prompt(girl_name: str, additional_text: str | None = None) -> str:
    """Формирует промпт для генерации изображения на основе персонажа."""
    base_prompts = {
        "Стейси": "1girl, 19 years old, blonde, blue eyes student, cute, friendly, anime style, soft light, beautiful, detailed, bedroom setting 1girl, masterpiece, best quality, detailed lighting, soft shadows, bedroom interior, sitting on bed, cozy atmosphere, sunlight through window, warm colors, natural pose, detailed face, expressive eyes, gentle smile, soft hair, realistic fabric, depth of field",
        "Аманда": "1girl, 32 years old, mature woman, milf, confident, elegant, anime style, dark hair, long dark hair, soft light, beautiful, detailed, sleeveless V-neck top, deep maroon reddish-brown color, ribbed textured fabric, three small dark buttons on neckline, fitted feminine silhouette, apartment living room, sitting on sofa, cozy atmosphere, sunlight through window, warm colors, natural pose, detailed face, expressive eyes, gentle smile, soft hair, realistic fabric, depth of field, masterpiece, best quality, detailed lighting, soft shadows",
        "Джейн": "1girl, 22 years old, red hair, country girl, confident and graceful, anime style, masterpiece, best quality, soft warm light, in a barn, rustic wood background, sitting on hay, gentle breeze moving her hair, short dress with light fabric, natural beauty, detailed textures, sunlight filtering through the barn walls, cinematic look",
    }
    
    prompt = base_prompts.get(girl_name, f"1girl, {girl_name}, anime style, soft light, beautiful, detailed")
    
    if additional_text:
        prompt = f"{prompt}, {additional_text}"
    
    return prompt


@router.message(CommandStart())
async def handle_start(message: Message) -> None:
    if not message.from_user:
        await message.answer("⚠️ Не могу определить пользователя.")
        return

    # Отправляем приветственное сообщение с встроенной клавиатурой
    await message.answer(
        "👋 Привет! Я бот ролевой игры с AI девушками.\n\n"
        "💕 Выбери девушку для начала диалога:",
        reply_markup=get_main_keyboard()
    )
    
    # Отправляем сообщение с инлайн кнопками для выбора девушек
    async with get_session() as session:
        girls = await get_all_girls(session)
        
        if not girls:
            await message.answer("⚠️ Персонажи пока не настроены. Попробуй позже.")
            return
        
        # Показываем первую девушку с навигацией
        if girls:
            first_girl = girls[0]
            keyboard = build_girl_keyboard(girls, current_index=0)
            
            # Получаем описание девушки
            description = get_girl_description(first_girl)
            
            # Формируем текст с информацией о девушке
            text = f"{first_girl.name}\n\n{description}"
            
            # Отправляем фото первой девушки, если есть
            image_path = get_girl_image_path(first_girl.name)
            if image_path:
                try:
                    photo = FSInputFile(image_path)
                    await message.answer_photo(photo, caption=text, reply_markup=keyboard)
                except Exception as exc:
                    logging.getLogger(__name__).warning(f"Не удалось отправить фото: {exc}")
                    await message.answer(text, reply_markup=keyboard)
            else:
                await message.answer(text, reply_markup=keyboard)
        else:
            await message.answer("⚠️ Персонажи пока не настроены. Попробуй позже.")


@router.message(Command("girl"))
async def handle_girl_info(message: Message) -> None:
    async with get_session() as session:
        girl = await get_default_girl(session)
    if not girl:
        await message.answer("👥 Пока нет доступных персонажей.")
        return
    await message.answer(f"💬 Сейчас с тобой общается {girl.name}.")


@router.message(Command("image"))
async def handle_generate_image(message: Message) -> None:
    """Генерирует изображение текущего персонажа через очередь."""
    if not message.from_user:
        await message.answer("⚠️ Не могу определить пользователя.")
        return

    async with get_session() as session:
        girl = await get_selected_girl(session, user_id=message.from_user.id)
        if not girl:
            girl = await get_default_girl(session)
            if girl:
                await set_selected_girl(session, user_id=message.from_user.id, girl_id=girl.id)

        if not girl:
            await message.answer("⚠️ Персонажи пока не настроены. Попробуй позже.")
            return

    # Формируем промпт для генерации изображения на основе персонажа
    additional = None
    if message.text and len(message.text.split()) > 1:
        additional = " ".join(message.text.split()[1:])
    
    prompt = build_image_prompt(girl.name, additional)

    # Устанавливаем флаг генерации
    if message.from_user:
        _generating_images[message.from_user.id] = None
    
    try:
        # Отправляем сообщение о начале генерации
        status_message = await message.answer(
            "🎨 Генерирую фото...\n"
            "⏱️ Генерация может занять обычно 20 секунд, пожалуйста, подождите."
        )
        
        # Добавляем задачу в очередь
        task_id = await enqueue_image_generation(
            user_id=message.from_user.id,
            prompt=prompt,
            girl_id=girl.id,
        )
        
        # Ожидаем результат (используем бот из контекста сообщения)
        from aiogram import Bot
        bot = message.bot
        task_result = await wait_for_task_result(bot, message, task_id)
        
        # Удаляем сообщение о генерации
        try:
            await status_message.delete()
        except Exception:
            pass
        
        if task_result:
            await send_image_from_task_result(bot, message, task_result, girl.name)
        else:
            await message.answer("❌ Не получилось сгенерировать изображение. Попробуй позже.")
    except Exception as exc:
        await message.answer("❌ Не получилось сгенерировать изображение. Проверь, что локальный API запущен.")
        logging.getLogger(__name__).exception("Ошибка при генерации изображения", exc_info=exc)
    finally:
        # Удаляем сообщение-предупреждение, если оно было отправлено
        if message.from_user:
            warning_msg = _generating_images.pop(message.from_user.id, None)
            if warning_msg:
                try:
                    await warning_msg.delete()
                except Exception:
                    pass


@router.message(lambda m: m.text and ("Главное меню" in m.text or m.text == "🏠 Главное меню"))
async def handle_main_menu(message: Message) -> None:
    """Обработчик кнопки 'Главное меню'."""
    if not message.from_user:
        await message.answer("⚠️ Не могу определить пользователя.")
        return

    keyboard = InlineKeyboardMarkup(
        inline_keyboard=[[InlineKeyboardButton(text="👤 Выбрать девушку", callback_data="choose_girl:0")]]
    )

    async with get_session() as session:
        # Проверяем, есть ли активный диалог, и завершаем его
        active_dialog_id = await get_active_dialog_id(session, user_id=message.from_user.id)
        if active_dialog_id:
            # Завершаем диалог (устанавливаем active_dialog_id в None)
            await set_active_dialog(session, user_id=message.from_user.id, dialog_id=None)
            await session.commit()
        
        girl = await get_selected_girl(session, user_id=message.from_user.id)
        if not girl:
            girl = await get_default_girl(session)

        if girl:
            text = (
                f"🏠 Главное меню\n\n"
                f"👤 Текущий персонаж: {girl.name}\n\n"
                f"Используй кнопку 'Выбрать девушку' для смены персонажа."
            )
        else:
            text = "🏠 Главное меню\n\nПерсонажи пока не настроены."

    await message.answer(text, reply_markup=keyboard)


async def build_history_keyboard(
    dialogs_list: list[tuple],  # list of (girl, dialog) tuples
    page: int,
    session,
) -> tuple[str, InlineKeyboardMarkup]:
    """Создаёт клавиатуру со списком диалогов и пагинацией."""
    total_pages = math.ceil(len(dialogs_list) / DIALOGS_PER_PAGE) if dialogs_list else 1
    start_idx = page * DIALOGS_PER_PAGE
    end_idx = start_idx + DIALOGS_PER_PAGE
    page_dialogs = dialogs_list[start_idx:end_idx]

    text = "📜 История чатов\n\nВыбери диалог для просмотра:\n\n"
    keyboard_buttons = []
    
    for girl, dialog in page_dialogs:
        msg_count = await get_message_count(session, dialog_id=dialog.id)
        dialog_date = dialog.updated_at.strftime("%d.%m.%Y") if dialog.updated_at else ""
        title = dialog.title or f"Диалог от {dialog.created_at.strftime('%d.%m.%Y') if dialog.created_at else ''}"
        button_text = f"💬 {girl.name} - {title[:25]} ({msg_count}) - {dialog_date}"
        keyboard_buttons.append([
            InlineKeyboardButton(
                text=button_text,
                callback_data=f"view_dialog:{dialog.id}"
            )
        ])
    
    # Кнопки пагинации
    nav_buttons = []
    if total_pages > 1:
        if page > 0:
            nav_buttons.append(
                InlineKeyboardButton(text="◀️ Назад", callback_data=f"history_page:{page - 1}")
            )
        if page < total_pages - 1:
            nav_buttons.append(
                InlineKeyboardButton(text="Вперёд ▶️", callback_data=f"history_page:{page + 1}")
            )
        if nav_buttons:
            keyboard_buttons.append(nav_buttons)
        
        # Показываем номер страницы
        text += f"\n📄 Страница {page + 1} из {total_pages}"

    keyboard = InlineKeyboardMarkup(inline_keyboard=keyboard_buttons)
    return text, keyboard


@router.message(lambda m: m.text and ("История чатов" in m.text or m.text == "📜 История чатов"))
async def handle_chat_history(message: Message) -> None:
    """Обработчик кнопки 'История чатов'."""
    if not message.from_user:
        await message.answer("⚠️ Не могу определить пользователя.")
        return

    async with get_session() as session:
        # Проверяем, есть ли активный диалог, и завершаем его
        active_dialog_id = await get_active_dialog_id(session, user_id=message.from_user.id)
        if active_dialog_id:
            # Завершаем диалог (устанавливаем active_dialog_id в None)
            await set_active_dialog(session, user_id=message.from_user.id, dialog_id=None)
            await session.commit()
        
        # Получаем все диалоги пользователя, сгруппированные по персонажам
        from app.repositories.dialogs import get_dialogs_by_girls
        dialogs_by_girls = await get_dialogs_by_girls(session, user_id=message.from_user.id)

        if not dialogs_by_girls:
            await message.answer(
                "📜 У тебя пока нет истории чатов с персонажами.\n"
                "💕 Начни диалог с любым персонажем!",
                reply_markup=get_main_keyboard(),
            )
            return

        # Преобразуем в плоский список (girl, dialog) для пагинации
        dialogs_list = []
        for girl, dialogs in dialogs_by_girls:
            for dialog in dialogs:
                dialogs_list.append((girl, dialog))
        
        # Сортируем по updated_at DESC (новые сначала)
        dialogs_list.sort(key=lambda x: x[1].updated_at, reverse=True)

        # Показываем первую страницу
        text, keyboard = await build_history_keyboard(dialogs_list, 0, session)
        await message.answer(text, reply_markup=keyboard)


@router.message(lambda m: m.text and ("Завершить диалог" in m.text or m.text == "❌ Завершить диалог"))
async def handle_end_dialogue(message: Message) -> None:
    """Обработчик кнопки 'Завершить диалог'."""
    if not message.from_user:
        await message.answer("⚠️ Не могу определить пользователя.")
        return

    async with get_session() as session:
        # Просто сбрасываем активный диалог, но не удаляем сам диалог
        # Диалог останется в истории чатов
        await set_active_dialog(session, user_id=message.from_user.id, dialog_id=None)
        await session.commit()
        
        girl = await get_selected_girl(session, user_id=message.from_user.id)
        girl_name = girl.name if girl else "персонажем"

    keyboard = InlineKeyboardMarkup(
        inline_keyboard=[[InlineKeyboardButton(text="👤 Выбрать девушку", callback_data="choose_girl:0")]]
    )
    
    await message.answer(
        f"✅ Диалог с {girl_name} завершён.\n\n"
        "💾 Диалог сохранён в истории чатов. "
        "Используй кнопку '👤 Выбрать девушку' для начала нового диалога или "
        "'📜 История чатов' для продолжения предыдущего.",
        reply_markup=keyboard,
    )
    await message.answer(reply_markup=get_main_keyboard())


@router.message(lambda m: m.text and ("Начать диалог заново" in m.text or m.text == "🔄 Начать диалог заново"))
async def handle_restart_dialogue(message: Message) -> None:
    """Обработчик кнопки 'Начать диалог заново'."""
    if not message.from_user:
        await message.answer("⚠️ Не могу определить пользователя.")
        return

    async with get_session() as session:
        girl = await get_selected_girl(session, user_id=message.from_user.id)
        if not girl:
            girl = await get_default_girl(session)

        if not girl:
            await message.answer("Персонажи пока не настроены.")
            return

        # Создаём новый диалог (начинаем заново)
        dialog = await create_dialog(
            session,
            user_id=message.from_user.id,
            girl_id=girl.id,
        )
        await set_active_dialog(session, user_id=message.from_user.id, dialog_id=dialog.id)
        await set_selected_girl(session, user_id=message.from_user.id, girl_id=girl.id, active_dialog_id=dialog.id)

        # Добавляем приветствие
        await add_message(
            session,
            dialog_id=dialog.id,
            role="assistant",
            content=girl.greeting,
        )
        await session.commit()

    await message.answer(
        f"🔄 Диалог с {girl.name} начат заново!\n\n{girl.greeting}",
        reply_markup=get_dialogue_keyboard(),
    )


@router.message()
async def handle_dialogue(message: Message) -> None:
    if not message.text:
        await message.answer("📝 Я понимаю только текстовые сообщения.")
        return

    if not message.from_user:
        await message.answer("⚠️ Не могу определить пользователя.")
        return
    
    # Проверяем, идет ли генерация изображения для этого пользователя
    if message.from_user.id in _generating_images:
        # Отправляем короткое уведомление
        # Примечание: всплывающие окна (alerts) доступны только для callback queries,
        # для обычных сообщений отправляем короткое уведомление
        warning_msg = await message.answer(
            "⏸️ Во время генерации изображения нельзя отправлять сообщения.\n"
            "⏱️ Пожалуйста, подождите завершения генерации."
        )
        # Сохраняем ссылку на сообщение-предупреждение, если его еще нет
        if _generating_images.get(message.from_user.id) is None:
            _generating_images[message.from_user.id] = warning_msg
        return

    reply_text: str | None = None
    girl_name: str | None = None
    active_dialog_id: int | None = None
    
    async with get_session() as session:
        # Получаем выбранного персонажа
        girl = await get_selected_girl(session, user_id=message.from_user.id)
        if not girl:
            girl = await get_default_girl(session)
            if girl:
                await set_selected_girl(session, user_id=message.from_user.id, girl_id=girl.id)

        if not girl:
            await message.answer("⚠️ Персонажи пока не настроены. Попробуй позже.")
            return
        
        girl_name = girl.name

        # Получаем активный диалог
        active_dialog_id = await get_active_dialog_id(session, user_id=message.from_user.id)
        if not active_dialog_id:
            # Если нет активного диалога, значит пользователь в главном меню
            # Не создаем новый диалог автоматически - нужно явно выбрать девушку
            keyboard = InlineKeyboardMarkup(
                inline_keyboard=[[InlineKeyboardButton(text="👤 Выбрать девушку", callback_data="choose_girl:0")]]
            )
            await message.answer(
                "💬 Для начала диалога выбери девушку через кнопку '👤 Выбрать девушку' или используй кнопки меню.",
                reply_markup=keyboard,
            )
            return
        else:
            # Проверяем, что диалог принадлежит текущему персонажу
            dialog = await get_dialog_by_id(session, active_dialog_id)
            if not dialog or dialog.girl_id != girl.id:
                # Создаём новый диалог, если активный диалог не соответствует персонажу
                dialog = await create_dialog(
                    session,
                    user_id=message.from_user.id,
                    girl_id=girl.id,
                )
                active_dialog_id = dialog.id
                await set_active_dialog(session, user_id=message.from_user.id, dialog_id=dialog.id)
                await set_selected_girl(session, user_id=message.from_user.id, girl_id=girl.id, active_dialog_id=dialog.id)
                
                # Добавляем приветствие в историю при создании нового диалога
                await add_message(
                    session,
                    dialog_id=dialog.id,
                    role="assistant",
                    content=girl.greeting,
                )

        # Добавляем сообщение пользователя
        await add_message(
            session,
            dialog_id=active_dialog_id,
            role="user",
            content=message.text,
        )

        # Получаем историю из активного диалога
        history = await get_recent_messages(
            session,
            dialog_id=active_dialog_id,
            limit=30,
        )

        history_payload = [
            {"role": msg.role, "content": msg.content}
            for msg in history
        ]
        
        await session.commit()  # Сохраняем сообщение пользователя

    # Генерируем ответ через очередь
    try:
        # Показываем индикатор загрузки
        status_message = await message.answer("💭 Думаю...")
        
        # Добавляем задачу в очередь
        task_id = await enqueue_reply_generation(
            user_id=message.from_user.id,
            system_prompt=girl.system_prompt,
            history=history_payload,
            dialog_id=active_dialog_id,
            user_message=message.text,
        )
        
        # Ожидаем результат
        bot = message.bot
        task_result = await wait_for_task_result(bot, message, task_id, timeout=60.0)
        
        # Удаляем индикатор загрузки
        try:
            await status_message.delete()
        except Exception:
            pass
        
        if task_result and "reply" in task_result:
            reply_text = task_result["reply"]
        else:
            # Fallback: генерируем напрямую, если очередь не работает
            client = VeniceClient()
            try:
                reply_text = await client.generate_reply(girl.system_prompt, history_payload)
                async with get_session() as session:
                    await add_message(
                        session,
                        dialog_id=active_dialog_id,
                        role="assistant",
                        content=reply_text,
                    )
                    await session.commit()
            except Exception as exc:
                await message.answer("⚠️ Не получилось получить ответ от модели. Попробуй позже.")
                logging.getLogger(__name__).exception("Ошибка при обращении к Venice API", exc_info=exc)
                return
            finally:
                await client.close()
    
    except Exception as exc:
        logging.getLogger(__name__).exception("Ошибка при генерации ответа через очередь", exc_info=exc)
        # Fallback: генерируем напрямую
        client = VeniceClient()
        try:
            reply_text = await client.generate_reply(girl.system_prompt, history_payload)
            async with get_session() as session:
                await add_message(
                    session,
                    dialog_id=active_dialog_id,
                    role="assistant",
                    content=reply_text,
                )
                await session.commit()
        except Exception as exc2:
            await message.answer("⚠️ Не получилось получить ответ от модели. Попробуй позже.")
            logging.getLogger(__name__).exception("Ошибка при обращении к Venice API", exc_info=exc2)
            return
        finally:
            await client.close()
    
    # Получаем информацию о пользователе для счётчика фото
    async with get_session() as session:
        from app.repositories.user_selected_girl import get_user_photos_used
        photos_used = await get_user_photos_used(session, user_id=message.from_user.id)

    if reply_text and girl_name:
        # Создаём клавиатуру с кнопкой "Получить фото" и счётчиком
        keyboard_buttons = []
        if photos_used < MAX_PHOTOS_PER_DIALOG:
            keyboard_buttons.append([
                InlineKeyboardButton(
                    text=f"📷 Получить фото ({photos_used}/{MAX_PHOTOS_PER_DIALOG})",
                    callback_data=f"get_photo:{active_dialog_id}"
                )
            ])
        else:
            keyboard_buttons.append([
                InlineKeyboardButton(
                    text=f"📷 Лимит фото исчерпан ({photos_used}/{MAX_PHOTOS_PER_DIALOG})",
                    callback_data="photo_limit_reached"
                )
            ])
        
        inline_keyboard = InlineKeyboardMarkup(inline_keyboard=keyboard_buttons)
        
        # Отправляем только текстовое сообщение с кнопкой
        await message.answer(reply_text, reply_markup=inline_keyboard)


def build_girl_keyboard(girls: list, current_index: int, selected_girl_id: int | None = None) -> InlineKeyboardMarkup:
    """Создаёт клавиатуру для одной девушки с навигацией и выбором."""
    total_girls = len(girls)
    if total_girls == 0:
        return InlineKeyboardMarkup(inline_keyboard=[])
    
    # Нормализуем индекс
    if current_index < 0:
        current_index = 0
    elif current_index >= total_girls:
        current_index = total_girls - 1
    
    current_girl = girls[current_index]
    is_selected = selected_girl_id is not None and current_girl.id == selected_girl_id
    
    keyboard_buttons = []
    
    # Кнопки навигации с номером
    nav_buttons = []
    if total_girls > 1:
        if current_index > 0:
            nav_buttons.append(InlineKeyboardButton(text="◀️ Назад", callback_data=f"choose_girl:{current_index - 1}"))
        else:
            # Если первая девушка, кнопка "Назад" ведет к последней
            nav_buttons.append(InlineKeyboardButton(text="◀️ Назад", callback_data=f"choose_girl:{total_girls - 1}"))
        
        # Номер девушки в середине
        nav_buttons.append(InlineKeyboardButton(
            text=f"📄 {current_index + 1} / {total_girls}",
            callback_data="girl_info_dummy"  # Неактивная кнопка для отображения
        ))
        
        if current_index < total_girls - 1:
            nav_buttons.append(InlineKeyboardButton(text="Вперёд ▶️", callback_data=f"choose_girl:{current_index + 1}"))
        else:
            # Если последняя девушка, кнопка "Вперёд" ведет к первой
            nav_buttons.append(InlineKeyboardButton(text="Вперёд ▶️", callback_data=f"choose_girl:0"))
        
        keyboard_buttons.append(nav_buttons)
    
    # Кнопка выбора отдельной строкой
        select_text = "✅ Выбрать" if is_selected else "👤 Выбрать"
    keyboard_buttons.append([
        InlineKeyboardButton(text=select_text, callback_data=f"select_girl:{current_girl.id}")
    ])
    
    return InlineKeyboardMarkup(inline_keyboard=keyboard_buttons)


@router.callback_query(lambda c: c.data == "girl_info_dummy")
async def handle_girl_info_dummy(callback: CallbackQuery) -> None:
    """Обработчик для неактивной кнопки с номером девушки."""
    await callback.answer()  # Просто отвечаем на callback без действий


@router.callback_query(lambda c: c.data and c.data.startswith("choose_girl:"))
async def handle_choose_girl_callback(callback: CallbackQuery) -> None:
    """Обработчик для показа одной девушки с навигацией."""
    # Отвечаем сразу, чтобы убрать индикатор загрузки
    await callback.answer()
    
    if not callback.from_user:
        return

    try:
        girl_index = int(callback.data.split(":")[1])
    except (ValueError, IndexError):
        girl_index = 0

    async with get_session() as session:
        girls = await get_all_girls(session)
        selected_girl = await get_selected_girl(session, user_id=callback.from_user.id)
        selected_girl_id = selected_girl.id if selected_girl else None

    if not girls:
        await callback.message.answer("👥 Пока нет доступных персонажей.")
        return

    # Нормализуем индекс
    total_girls = len(girls)
    if girl_index < 0:
        girl_index = 0
    elif girl_index >= total_girls:
        girl_index = total_girls - 1

    current_girl = girls[girl_index]
    
    # Формируем текст с информацией о девушке
    is_selected = selected_girl_id is not None and current_girl.id == selected_girl_id
    marker = "✅ " if is_selected else ""
    
    # Получаем описание девушки
    description = get_girl_description(current_girl)
    
    text = f"{marker}{current_girl.name}\n\n{description}"

    keyboard = build_girl_keyboard(girls, girl_index, selected_girl_id)
    
    # Получаем фото девушки
    image_path = get_girl_image_path(current_girl.name)
    
    if image_path:
        try:
            photo = FSInputFile(image_path)
            # Проверяем, есть ли уже фото в сообщении
            if callback.message.photo:
                # Если есть фото, редактируем его
                from aiogram.types import InputMediaPhoto
                media = InputMediaPhoto(media=photo, caption=text)
                await callback.message.edit_media(media, reply_markup=keyboard)
            else:
                # Если нет фото, отправляем новое
                await callback.message.answer_photo(photo, caption=text, reply_markup=keyboard)
            return
        except Exception as exc:
            logging.getLogger(__name__).warning(f"Не удалось отправить фото: {exc}")
    
    # Если фото не удалось отправить, отправляем/редактируем текстовое сообщение
    if callback.message.photo:
        # Если было фото, удаляем его и отправляем текстовое сообщение
        try:
            await callback.message.delete()
        except Exception:
            pass
        await callback.message.answer(text, reply_markup=keyboard)
    else:
        await callback.message.edit_text(text, reply_markup=keyboard)


@router.callback_query(lambda c: c.data and c.data.startswith("select_girl:"))
async def handle_select_girl_callback(callback: CallbackQuery) -> None:
    """Обработчик для выбора персонажа."""
    if not callback.from_user:
        await callback.answer("⚠️ Ошибка: не могу определить пользователя.", show_alert=True)
        return

    try:
        girl_id = int(callback.data.split(":")[1])
    except (ValueError, IndexError):
        await callback.answer("⚠️ Ошибка: неверный ID персонажа.", show_alert=True)
        return

    async with get_session() as session:
        girl = await get_girl_by_id(session, girl_id)
        if not girl:
            await callback.answer("👤 Персонаж не найден.", show_alert=True)
            return

        # Создаём новый диалог при выборе девушки
        dialog = await create_dialog(
            session,
            user_id=callback.from_user.id,
            girl_id=girl_id,
        )
        await set_selected_girl(session, user_id=callback.from_user.id, girl_id=girl_id, active_dialog_id=dialog.id)
        await set_active_dialog(session, user_id=callback.from_user.id, dialog_id=dialog.id)
        
        # Добавляем приветствие в историю
        from app.repositories.messages import add_message
        await add_message(
            session,
            dialog_id=dialog.id,
            role="assistant",
            content=girl.greeting,
        )
        await session.commit()

    # Редактируем сообщение с выбором девушек на введение в сюжет
    story_intro = get_girl_story_intro(girl.name)
    image_path = get_girl_image_path(girl.name)
    
    # Удаляем старое сообщение с выбором девушек
    try:
        await callback.message.delete()
    except Exception as exc:
        logging.getLogger(__name__).warning(f"Не удалось удалить старое сообщение: {exc}")
    
    # Отправляем новое сообщение с введением в сюжет
    if image_path:
        try:
            photo = FSInputFile(image_path)
            await callback.message.answer_photo(
                photo,
                caption=story_intro,
                reply_markup=get_dialogue_keyboard()
            )
        except Exception as exc:
            logging.getLogger(__name__).warning(f"Не удалось отправить фото: {exc}")
            # Если не удалось отправить фото, отправляем текстовое сообщение
            await callback.message.answer(
                story_intro,
                reply_markup=get_dialogue_keyboard()
            )
    else:
        # Если фото не найдено, отправляем текстовое сообщение
        await callback.message.answer(
            story_intro,
            reply_markup=get_dialogue_keyboard()
        )
    
    await callback.answer(f"✅ Выбрана {girl.name}!")


@router.callback_query(lambda c: c.data and c.data.startswith("view_dialog:"))
async def handle_view_history_callback(callback: CallbackQuery) -> None:
    """Обработчик для просмотра истории конкретного диалога."""
    # Отвечаем сразу
    await callback.answer()
    
    if not callback.from_user:
        return

    try:
        parts = callback.data.split(":")
        dialog_id = int(parts[1])
    except (ValueError, IndexError):
        await callback.answer("⚠️ Ошибка: неверный формат данных.", show_alert=True)
        return

    async with get_session() as session:
        from app.repositories.dialogs import get_dialog_by_id
        
        dialog = await get_dialog_by_id(session, dialog_id)
        if not dialog:
            await callback.message.answer("💬 Диалог не найден.")
            return
        
        # Проверяем, что диалог принадлежит пользователю
        if dialog.user_id != callback.from_user.id:
            await callback.message.answer("🔒 У тебя нет доступа к этому диалогу.")
            return
        
        girl = await get_girl_by_id(session, dialog.girl_id)
        if not girl:
            await callback.message.answer("👤 Персонаж не найден.")
            return

        # Получаем последние сообщения диалога (8 сообщений)
        recent_messages = await get_recent_messages(
            session,
            dialog_id=dialog_id,
            limit=8,
        )

        if not recent_messages:
            await callback.message.answer("📜 История пуста.")
            return

        # Формируем текст истории с датами
        dialog_title = dialog.title or f"Диалог от {dialog.created_at.strftime('%d.%m.%Y') if dialog.created_at else ''}"
        text = f"💬 {girl.name} - {dialog_title}\n\n"
        text += "─" * 30 + "\n\n"

        for msg in recent_messages:
            role_emoji = "👤 Ты" if msg.role == "user" else f"🤖 {girl.name}"
            
            # Форматируем дату
            msg_date = msg.created_at
            if msg_date:
                date_str = msg_date.strftime("%d.%m.%Y %H:%M")
            else:
                date_str = "Неизвестно"
            
            # Обрезаем длинные сообщения
            content = msg.content
            if len(content) > 150:
                content = content[:150] + "..."
            
            text += f"{role_emoji}\n"
            text += f"📅 {date_str}\n"
            text += f"{content}\n\n"
            text += "─" * 30 + "\n\n"

        # Формируем клавиатуру
        keyboard_buttons = [
            [InlineKeyboardButton(text="💬 Продолжить чат", callback_data=f"continue_dialog:{dialog_id}")],
            [InlineKeyboardButton(text="🔙 К списку чатов", callback_data="back_to_history_list")],
        ]

        keyboard = InlineKeyboardMarkup(inline_keyboard=keyboard_buttons)
        await callback.message.edit_text(text, reply_markup=keyboard)


@router.callback_query(lambda c: c.data and c.data == "back_to_history_list")
async def handle_back_to_history_list(callback: CallbackQuery) -> None:
    """Обработчик для возврата к списку диалогов в истории."""
    # Отвечаем сразу
    await callback.answer()
    
    if not callback.from_user:
        return

    async with get_session() as session:
        from app.repositories.dialogs import get_dialogs_by_girls
        dialogs_by_girls = await get_dialogs_by_girls(session, user_id=callback.from_user.id)

        if not dialogs_by_girls:
            await callback.message.edit_text(
                "📜 У тебя пока нет истории чатов с персонажами.\n"
                "💕 Начни диалог с любым персонажем!",
            )
            return

        # Преобразуем в плоский список (girl, dialog) для пагинации
        dialogs_list = []
        for girl, dialogs in dialogs_by_girls:
            for dialog in dialogs:
                dialogs_list.append((girl, dialog))
        
        # Сортируем по updated_at DESC (новые сначала)
        dialogs_list.sort(key=lambda x: x[1].updated_at, reverse=True)

        # Показываем первую страницу
        text, keyboard = await build_history_keyboard(dialogs_list, 0, session)
        await callback.message.edit_text(text, reply_markup=keyboard)


@router.callback_query(lambda c: c.data and c.data.startswith("history_page:"))
async def handle_history_page_callback(callback: CallbackQuery) -> None:
    """Обработчик для пагинации истории чатов."""
    # Отвечаем сразу
    await callback.answer()
    
    if not callback.from_user:
        return

    try:
        page = int(callback.data.split(":")[1])
    except (ValueError, IndexError):
        await callback.answer("⚠️ Ошибка: неверный номер страницы.", show_alert=True)
        return

    async with get_session() as session:
        from app.repositories.dialogs import get_dialogs_by_girls
        dialogs_by_girls = await get_dialogs_by_girls(session, user_id=callback.from_user.id)

        if not dialogs_by_girls:
            await callback.answer("📜 История пуста.", show_alert=True)
            return

        # Преобразуем в плоский список (girl, dialog) для пагинации
        dialogs_list = []
        for girl, dialogs in dialogs_by_girls:
            for dialog in dialogs:
                dialogs_list.append((girl, dialog))
        
        # Сортируем по updated_at DESC (новые сначала)
        dialogs_list.sort(key=lambda x: x[1].updated_at, reverse=True)

        # Проверяем валидность страницы
        total_pages = math.ceil(len(dialogs_list) / DIALOGS_PER_PAGE) if dialogs_list else 1
        if page < 0 or page >= total_pages:
            await callback.answer("⚠️ Неверный номер страницы.", show_alert=True)
            return

        # Показываем запрошенную страницу
        text, keyboard = await build_history_keyboard(dialogs_list, page, session)
        await callback.message.edit_text(text, reply_markup=keyboard)


@router.callback_query(lambda c: c.data and c.data.startswith("get_photo:"))
async def handle_get_photo_callback(callback: CallbackQuery) -> None:
    """Обработчик для кнопки 'Получить фото'."""
    if not callback.from_user:
        await callback.answer("⚠️ Ошибка: не могу определить пользователя.")
        return

    try:
        dialog_id = int(callback.data.split(":")[1])
    except (ValueError, IndexError):
        await callback.answer("Ошибка: неверный ID диалога.", show_alert=True)
        return

    async with get_session() as session:
        from app.repositories.dialogs import get_dialog_by_id
        from app.repositories.user_selected_girl import get_user_photos_used, increment_user_photos_used
        
        dialog = await get_dialog_by_id(session, dialog_id)
        if not dialog:
            await callback.answer("💬 Диалог не найден.", show_alert=True)
            return
        
        # Проверяем, что диалог принадлежит пользователю
        if dialog.user_id != callback.from_user.id:
            await callback.answer("🔒 У тебя нет доступа к этому диалогу.", show_alert=True)
            return
        
        # Проверяем общий лимит фото для пользователя (для всех девушек)
        photos_used = await get_user_photos_used(session, user_id=callback.from_user.id)
        if photos_used >= MAX_PHOTOS_PER_DIALOG:
            await callback.answer(f"📷 Лимит фото исчерпан ({photos_used}/{MAX_PHOTOS_PER_DIALOG})", show_alert=True)
            return
        
        # Получаем информацию о персонаже
        girl = await get_girl_by_id(session, dialog.girl_id)
        if not girl:
            await callback.answer("👤 Персонаж не найден.", show_alert=True)
            return
        
        # Получаем все сообщения для поиска последнего обмена
        all_messages = await get_all_messages(session, dialog_id=dialog_id)
        
        # Используем базовый детальный промпт как основу
        base_prompt = build_image_prompt(girl.name)
        
        # Контекст из диалога обязателен, если есть история
        # Берем только последнее сообщение персонажа и последнее сообщение пользователя
        if all_messages:
            last_assistant = None
            last_user = None
            # Идем с конца, чтобы найти последние сообщения каждого типа
            for msg in reversed(all_messages):
                if msg.role == "assistant" and last_assistant is None:
                    last_assistant = msg
                elif msg.role == "user" and last_user is None:
                    last_user = msg
                # Если нашли оба, можно прекратить поиск
                if last_assistant and last_user:
                    break
            
            # Формируем диалог: сначала пользователь, потом персонаж (если есть)
            recent_dialogue = []
            if last_user:
                recent_dialogue.append({"role": "user", "content": last_user.content})
            if last_assistant:
                recent_dialogue.append({"role": "assistant", "content": last_assistant.content})
            
            venice_client = VeniceClient()
            try:
                girl_description = f"{girl.name}, {girl.system_prompt[:200]}"
                dialogue_context = await venice_client.generate_image_prompt(
                    girl_name=girl.name,
                    girl_description=girl_description,
                    recent_dialogue=recent_dialogue,
                )
                # Контекст из диалога обязателен - комбинируем с базовым промптом
                if dialogue_context and len(dialogue_context.strip()) > 10:
                    # Добавляем контекст к базовому промпту (базовый промпт сохраняет все ключевые слова качества)
                    image_prompt = f"{base_prompt}, {dialogue_context}"
                else:
                    # Если контекст слишком короткий или пустой, используем только базовый
                    image_prompt = base_prompt
            except Exception as exc:
                logging.getLogger(__name__).warning(f"Не удалось добавить контекст через ИИ: {exc}")
                # Fallback: используем только базовый промпт
                image_prompt = base_prompt
            finally:
                await venice_client.close()
        else:
            # Если нет истории, используем только базовый промпт
            image_prompt = base_prompt
        
        # Генерируем и отправляем изображение через очередь
        # Устанавливаем флаг генерации
        if callback.from_user:
            _generating_images[callback.from_user.id] = None
        
        try:
            # Отправляем сообщение о начале генерации
            status_message = await callback.message.answer(
                "🎨 Генерирую фото...\n"
                "⏱️ Генерация может занять обычно 20 секунд, пожалуйста, подождите."
            )
            
            # Добавляем задачу в очередь
            task_id = await enqueue_image_generation(
                user_id=callback.from_user.id,
                prompt=image_prompt,
                dialog_id=dialog_id,
                girl_id=girl.id,
            )
            
            # Ожидаем результат
            bot = callback.message.bot
            task_result = await wait_for_task_result(bot, callback.message, task_id)
            
            # Удаляем сообщение о генерации
            try:
                await status_message.delete()
            except Exception:
                pass
            
            if task_result:
                await send_image_from_task_result(bot, callback.message, task_result, girl.name)
                
                # Обновляем общий счётчик фото для пользователя
                async with get_session() as session:
                    await increment_user_photos_used(session, user_id=callback.from_user.id)
                    new_photos_used = await get_user_photos_used(session, user_id=callback.from_user.id)
                    await session.commit()
                
                await callback.answer(f"✅ Фото отправлено! ({new_photos_used}/{MAX_PHOTOS_PER_DIALOG})")
            else:
                await callback.answer("❌ Не получилось сгенерировать изображение. Попробуй позже.", show_alert=True)
        except ValueError as exc:
            error_msg = str(exc)
            logging.getLogger(__name__).warning(f"Не удалось сгенерировать изображение: {error_msg}")
            await callback.answer(f"❌ Ошибка генерации изображения: {error_msg}", show_alert=True)
        except Exception as exc:
            logging.getLogger(__name__).exception("Ошибка при генерации изображения", exc_info=exc)
            await callback.answer("❌ Ошибка при генерации изображения", show_alert=True)
        finally:
            # Удаляем сообщение-предупреждение, если оно было отправлено
            if callback.from_user:
                warning_msg = _generating_images.pop(callback.from_user.id, None)
                if warning_msg:
                    try:
                        await warning_msg.delete()
                    except Exception:
                        pass


@router.callback_query(lambda c: c.data and c.data == "photo_limit_reached")
async def handle_photo_limit_reached(callback: CallbackQuery) -> None:
    """Обработчик для кнопки с исчерпанным лимитом фото."""
    await callback.answer(f"📷 Лимит фото исчерпан ({MAX_PHOTOS_PER_DIALOG}/{MAX_PHOTOS_PER_DIALOG})", show_alert=True)


@router.callback_query(lambda c: c.data and c.data.startswith("continue_dialog:"))
async def handle_continue_chat_callback(callback: CallbackQuery) -> None:
    """Обработчик для продолжения конкретного диалога."""
    if not callback.from_user:
        await callback.answer("⚠️ Ошибка: не могу определить пользователя.", show_alert=True)
        return
    
    # Отвечаем сразу для быстрого отклика
    await callback.answer()

    try:
        dialog_id = int(callback.data.split(":")[1])
    except (ValueError, IndexError):
        await callback.answer("Ошибка: неверный ID диалога.", show_alert=True)
        return

    async with get_session() as session:
        from app.repositories.dialogs import get_dialog_by_id
        
        dialog = await get_dialog_by_id(session, dialog_id)
        if not dialog:
            await callback.answer("💬 Диалог не найден.", show_alert=True)
            return
        
        # Проверяем, что диалог принадлежит пользователю
        if dialog.user_id != callback.from_user.id:
            await callback.answer("🔒 У тебя нет доступа к этому диалогу.", show_alert=True)
            return
        
        girl = await get_girl_by_id(session, dialog.girl_id)
        if not girl:
            await callback.answer("👤 Персонаж не найден.", show_alert=True)
            return

        # Переключаемся на этого персонажа и устанавливаем активный диалог
        # Важно: сначала устанавливаем активный диалог, потом персонажа, чтобы они были синхронизированы
        await set_selected_girl(session, user_id=callback.from_user.id, girl_id=girl.id, active_dialog_id=dialog_id)
        
        # Обновляем updated_at диалога, чтобы он считался активным
        from datetime import datetime, timezone
        dialog.updated_at = datetime.now(timezone.utc)
        await session.commit()

        # Получаем все сообщения для поиска последнего сообщения персонажа
        all_messages = await get_all_messages(session, dialog_id=dialog_id)
        
        # Ищем последнее сообщение от персонажа (assistant)
        last_assistant_msg = None
        if all_messages:
            for msg in reversed(all_messages):
                if msg.role == "assistant":
                    last_assistant_msg = msg
                    break

    # Первое сообщение - уведомление о продолжении чата
    await callback.message.edit_text(f"💬 Продолжаем чат с {girl.name}! ✨")
    
    # Второе сообщение - последнее сообщение персонажа с клавиатурой диалога
    if last_assistant_msg:
        # Если есть последнее сообщение от персонажа, показываем его с клавиатурой
        await callback.message.answer(
            last_assistant_msg.content,
            reply_markup=get_dialogue_keyboard()
        )
    else:
        # Если нет сообщений от персонажа, показываем приветствие
        await callback.message.answer(
            girl.greeting,
            reply_markup=get_dialogue_keyboard()
        )

