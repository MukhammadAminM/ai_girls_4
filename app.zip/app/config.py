from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    bot_token: str
    database_url: str
    venice_api_key: str
    venice_api_base_url: str = "https://api.venice.ai/api/v1"
    venice_model: str = "venice-uncensored"
    image_api_url: str = "http://127.0.0.1:8000"
    image_default_width: int = 832
    image_default_height: int = 1216
    image_default_steps: int = 24
    image_default_cfg: float = 5.0
    image_default_seed: int = -1
    image_default_negative_prompt: str = "lowres, bad anatomy, blurry, out of focus, extra limbs, bad hands, bad face, low quality, deformed, watermark, signature, text, cropped, overexposed, oversaturated"
    image_default_lora_name: str | None = None
    image_default_lora_strength_model: float = 0.80
    image_default_lora_strength_clip: float = 0.90
    
    # Redis настройки
    redis_url: str = "redis://localhost:6379/0"
    redis_queue_prefix: str = "ai_girls:queue:"
    redis_result_prefix: str = "ai_girls:result:"
    redis_result_ttl: int = 3600  # Время жизни результатов в секундах (1 час)

    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        case_sensitive=False,
        extra="ignore",
    )


settings = Settings()  # type: ignore[arg-type]


