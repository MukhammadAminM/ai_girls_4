from typing import Any

import httpx

from app.config import settings


def _normalize_base_url(url: str) -> str:
    # Приводим к варианту .../api/v1 во избежание 404
    clean = url.rstrip("/")
    if clean.endswith("/v1") and "/api/" not in clean:
        return clean[:-3] + "/api/v1"
    if clean.endswith("/api"):
        return clean + "/v1"
    if not (clean.endswith("/api/v1")) and clean.endswith("/v1") is False and clean.endswith("/api/v1") is False:
        # если дали базу без версии, добавим /api/v1
        return clean + "/api/v1"
    return clean


class VeniceClient:
    def __init__(self) -> None:
        base_url = _normalize_base_url(settings.venice_api_base_url)
        self._client = httpx.AsyncClient(
            base_url=base_url,
            headers={
                "Authorization": f"Bearer {settings.venice_api_key}",
                "Content-Type": "application/json",
            },
            timeout=30.0,
        )

    async def generate_reply(self, system_prompt: str, history: list[dict[str, str]]) -> str:
        messages: list[dict[str, str]] = [{"role": "system", "content": system_prompt}, *history]
        payload: dict[str, Any] = {
            "model": settings.venice_model,
            "messages": messages,
        }
        response = await self._client.post("/chat/completions", json=payload)
        response.raise_for_status()
        data = response.json()
        return data["choices"][0]["message"]["content"]

    async def generate_image_prompt(
        self,
        girl_name: str,
        girl_description: str,
        recent_dialogue: list[dict[str, str]],
    ) -> str:
        """
        Генерирует промпт для изображения на основе диалога с персонажем.
        
        Args:
            girl_name: Имя персонажа
            girl_description: Описание персонажа
            recent_dialogue: Последние сообщения диалога (обычно 3-5 последних)
        
        Returns:
            str: Промпт для генерации изображения
        """
        system_prompt = (
            f"Ты помощник для генерации ДОПОЛНИТЕЛЬНОГО контекста для промптов изображений. "
            f"Персонаж: {girl_name} - {girl_description}. "
            f"ВАЖНО: Ты должен создать дополнение к базовому промпту, которое ПЕРЕЗАПИСЫВАЕТ базовое описание одежды и ситуации, "
            f"если в диалоге описана другая ситуация. "
            f"Твоя задача: на основе последних сообщений диалога создать ДЕТАЛЬНОЕ дополнение к промпту, "
            f"которое описывает: текущую ситуацию, позу, эмоции, одежду (или её отсутствие) ИЗ ДИАЛОГА, "
            f"детали тела, если они упомянуты (грудь, поза и т.д.). "
            f"КРИТИЧЕСКИ ВАЖНО: Если в диалоге персонаж раздевается, снимает одежду, показывает что-то - "
            f"дополнение ДОЛЖНО ЯВНО описывать это: 'topless, removing bra, nude, breasts visible' и т.д. "
            f"Если персонаж в процессе раздевания - опиши это: 'unbuttoning shirt, removing top, partially nude' и т.д. "
            f"Если персонаж держит что-то в руках (бокал вина, предметы) - опиши это. "
            f"Дополнение должно ПЕРЕЗАПИСЫВАТЬ базовое описание одежды, если в диалоге описана другая ситуация. "
            f"Используй английский язык, формат: '[ситуация/поза], [одежда/обнажение ИЗ ДИАЛОГА], [эмоции], [предметы в руках], [детали из диалога]'. "
            f"НЕ включай общие слова качества (masterpiece, best quality и т.д.) - они уже есть в базовом промпте. "
            f"Будь максимально конкретным и детальным. Если персонаж раздевается - опиши это явно и детально. "
            f"Верни ТОЛЬКО дополнение к промпту (10-25 слов), без дополнительных объяснений."
        )
        
        # Формируем контекст из последних сообщений
        dialogue_context = "\n".join([
            f"{msg['role']}: {msg['content']}" 
            for msg in recent_dialogue[-8:]  # Последние 8 сообщений для лучшего контекста
        ])
        
        user_message = (
            f"Вот последние сообщения из диалога:\n{dialogue_context}\n\n"
            f"Создай ДЕТАЛЬНОЕ дополнение к промпту (10-25 слов), которое описывает ТОЧНУЮ текущую ситуацию из диалога. "
            f"КРИТИЧЕСКИ ВАЖНО: Если в диалоге персонаж раздевается, снимает одежду, показывает что-то - "
            f"дополнение ДОЛЖНО ЯВНО описывать это: 'topless, removing bra, unbuttoning shirt, nude, breasts visible, lace bra visible' и т.д. "
            f"Если персонаж в процессе раздевания - опиши это детально: 'unbuttoning blouse, removing top, partially nude, showing lace bra' и т.д. "
            f"Если персонаж держит что-то в руках (бокал вина, предметы) - обязательно опиши это: 'holding wine glass, red wine in hand' и т.д. "
            f"Если персонаж сидит на стуле, диване, кровати - опиши это: 'sitting on chair, sitting on sofa' и т.д. "
            f"Дополнение должно ПЕРЕЗАПИСЫВАТЬ базовое описание одежды, если в диалоге описана другая ситуация. "
            f"Будь максимально конкретным и детальным. Если персонаж раздевается - опиши каждый этап явно. "
            f"Используй английский язык, формат: '[ситуация/поза], [одежда/обнажение ИЗ ДИАЛОГА], [эмоции], [предметы в руках], [детали из диалога]'. "
            f"НЕ включай слова качества (masterpiece, best quality, detailed и т.д.) - они уже есть в базовом промпте. "
            f"Когда дело касается 18+, добавь в начало промпта 'nsfw, explicit' и в конце 'nsfw, explicit'. "
            f"Верни ТОЛЬКО детальное дополнение (10-25 слов), без дополнительных объяснений."
        )
        
        messages = [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_message},
        ]
        
        payload: dict[str, Any] = {
            "model": settings.venice_model,
            "messages": messages,
        }
        response = await self._client.post("/chat/completions", json=payload)
        response.raise_for_status()
        data = response.json()
        prompt = data["choices"][0]["message"]["content"].strip()
        
        # Убираем возможные кавычки и форматирование
        prompt = prompt.strip('"').strip("'").strip()
        
        return prompt

    async def close(self) -> None:
        await self._client.aclose()


