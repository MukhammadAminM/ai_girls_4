import asyncio

from aiogram import Bot

from app.bot import setup_dispatcher
from app.config import settings
from app.db import engine
from app.models import Base
from app.repositories.girls import ensure_all_girls


async def on_startup() -> None:
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)

    from app.db import get_session

    async with get_session() as session:
        await ensure_all_girls(session)


async def main() -> None:
    await on_startup()

    bot = Bot(settings.bot_token)
    dp = setup_dispatcher()

    await dp.start_polling(bot)


if __name__ == "__main__":
    asyncio.run(main())


